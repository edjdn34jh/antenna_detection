# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 21:36:45 2026

@author: Formation
"""

from ultralytics import YOLO
model = YOLO("yolov8n.pt")  # modèle nano pré-entraîné
dataset_yaml = r"D:\Documents\tp_deep\dataset\data.yaml"

model.train(data=dataset_yaml, epochs=1, imgsz=640, show=True) #imgsz prendre la taille de chaque image



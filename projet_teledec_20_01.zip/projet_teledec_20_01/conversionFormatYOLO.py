import json
import os
from PIL import Image
from pathlib import Path

# -----------------------------
# CONFIGURATION À MODIFIER
# -----------------------------
json_dir = r"D:\Documents\tp_deep\save"      # dossier avec tous les JSON LabelImg
img_dir = r"D:\Documents\tp_deep"            # dossier avec les images
output_dir = r"D:\Documents\tp_deep\txt"   # dossier de sortie
classes_file = "classes.txt"  # fichier des classes

# -----------------------------
# CRÉER LES DOSSIERS DE SORTIE
# -----------------------------
images_output = os.path.join(output_dir, "images")
labels_output = os.path.join(output_dir, "labels")
os.makedirs(images_output, exist_ok=True)
os.makedirs(labels_output, exist_ok=True)

# -----------------------------
# EXTRAIRE TOUTES LES CLASSES DES JSON
# -----------------------------
all_classes = set()
for json_file in os.listdir(json_dir):
    if not json_file.endswith(".json"):
        continue
    with open(os.path.join(json_dir, json_file), "r") as f:
        data = json.load(f)
    for item in data:
        for ann in item["annotations"]:
            all_classes.add(ann["label"])

all_classes = sorted(list(all_classes))
with open(os.path.join(output_dir, classes_file), "w") as f:
    f.write("\n".join(all_classes))

print(f"Classes détectées : {all_classes}")

# -----------------------------
# CONVERSION JSON → YOLO TXT
# -----------------------------
for json_file in os.listdir(json_dir):
    if not json_file.endswith(".json"):
        continue

    with open(os.path.join(json_dir, json_file), "r") as f:
        data = json.load(f)

    for item in data:
        img_name = item["image"]
        img_path = os.path.join(img_dir, img_name)

        # Vérifie que l'image existe
        if not os.path.exists(img_path):
            print(f"⚠️ Image manquante : {img_path}")
            continue

        # Copie l'image dans le dossier YOLO
        Path(os.path.join(images_output, img_name)).write_bytes(Path(img_path).read_bytes())

        # Récupérer la taille de l'image
        with Image.open(img_path) as im:
            img_w, img_h = im.size

        txt_lines = []
        for ann in item["annotations"]:
            cls = ann["label"]
            if cls not in all_classes:
                continue
            cls_id = all_classes.index(cls)

            # Coordonnées du JSON LabelImg
            x = ann["coordinates"]["x"]
            y = ann["coordinates"]["y"]
            w = ann["coordinates"]["width"]
            h = ann["coordinates"]["height"]

            # Conversion YOLO normalisée
            x_center = (x + w / 2) / img_w
            y_center = (y + h / 2) / img_h
            box_w = w / img_w
            box_h = h / img_h

            txt_lines.append(f"{cls_id} {x_center:.6f} {y_center:.6f} {box_w:.6f} {box_h:.6f}")

        # Sauvegarde fichier .txt
        txt_file = os.path.join(labels_output, os.path.splitext(img_name)[0] + ".txt")
        with open(txt_file, "w") as f:
            f.write("\n".join(txt_lines))

print("✅ Conversion JSON → YOLO terminée !")

# -----------------------------
# CREATION DATA.YAML POUR YOLOV8
# -----------------------------
data_yaml = f"""
train: {images_output}
val: {images_output}
nc: {len(all_classes)}
names: {all_classes}
"""

with open(os.path.join(output_dir, "data.yaml"), "w") as f:
    f.write(data_yaml.strip())

print(f"✅ Fichier data.yaml créé dans {output_dir}")
